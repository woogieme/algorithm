package com.ssafy.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day0427ProfessorHwApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day0427ProfessorHwApplication.class, args);
	}

}
