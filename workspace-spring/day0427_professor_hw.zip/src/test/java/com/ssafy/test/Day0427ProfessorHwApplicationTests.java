package com.ssafy.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day0427ProfessorHwApplicationTests {

	@Test
	void contextLoads() {
	}

}
