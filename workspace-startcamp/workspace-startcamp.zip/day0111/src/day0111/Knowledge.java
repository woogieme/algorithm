package day0111;

public class Knowledge {
	public static void main(String[] args) {
		//위치만 담아라
		//참조 대입, 기초 대입 메커니즘은 다르다
		//들고다닐수가없어서 어디있는지 알기위해서 사용하는것이 참조 대입형
		
		//참조자료형은 변수에 대입되는게 객체 자체가아니라 객체의 위치 정보만 들어감.
		double result = (double)5/2;
		System.out.println(result);
	}
}
