package day01117;

public class BookManager {
	final int MAX_SIZE=100;
	Book[][] books = new Book[MAX_SIZE][6];
	int size;
	
	
	
	public void add(Book book) {
		
		
		
	}
	
	public void remove(String isbn) {
			
	}
}
