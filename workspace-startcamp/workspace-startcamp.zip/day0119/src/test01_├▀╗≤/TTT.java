package test01_추상;

public class TTT {//extends StringBufferInputStream{
//너의 부모 클래스에 기본 생성자가 정의되어있지않아. 그래서 super호출해서 부모생성자를만들어
}
