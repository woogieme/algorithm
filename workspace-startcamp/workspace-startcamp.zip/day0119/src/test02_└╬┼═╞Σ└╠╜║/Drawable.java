package test02_인터페이스;

// 클래스 아님. 변수나 메소드 정의하지 않음. 마치 그냥 메뉴판이나 다름없음.
// 규칙만 집어넣은것
public interface Drawable {
	void draw();
}
