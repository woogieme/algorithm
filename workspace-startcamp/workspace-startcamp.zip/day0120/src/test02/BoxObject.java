package test02;

public class BoxObject {
	private Object data;
	
	public void setData(Object data) {
		this.data = data;
	}
	public Object getData() {
		return data;
	}

}
