package dayTest;

public class Car {
	static int a=100;
	int b=10;

}
