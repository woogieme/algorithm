package project4.p2040;

public class ArticleManager {
	private final int MAX_ARTICLE_SIZE=100;
	private Article[] articles= new Article[MAX_ARTICLE_SIZE];
	private int articleSize;
}
