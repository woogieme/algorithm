package project4.p2040;

public class UserManager {
	private final int MAX_SIZE =100;
	private User[] user = new User[MAX_SIZE];
	private User loginUser;
	public void signup(User user) {
		
	};
	
	public User login(String id, String password) {
		return loginUser;
	};
	
	public void logout() {
		
	};
	
	public User getLoginUser() {
		return loginUser;
	};
	
	public User getUser(int userSeq) {
		return loginUser;
	};
	
}
