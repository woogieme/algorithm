package projectSSAFY;

import java.util.Arrays;

public class BookManagerImpl implements IBookManager{
	private final int MAX_SIZE=100;
	private Book[] books =new Book[MAX_SIZE];
	private int size;
	private BookManagerImpl() {}
	private static BookManagerImpl instance = new BookManagerImpl();
	public static BookManagerImpl getInstance() {
		return instance;
	}
	
	public void add(Book book) {
		if(size<MAX_SIZE) books[size++] = book;
	}//end for add()
	
	Book[] getList() {
		Book[] temp = new Book[size];
		for(int i=0; i<books.length; i++) {
			if (books[i]!=null) {
				temp[i] = books[i];
//				break;
			}
		}
		return temp;
		//return Arrays.copyOfRange(books, 0, size);
	}//end for getList()
	
	public Magazine[] getMagazines() {
		int cnt=0;
		for(int i=0; i<size; i++) {
			if (books[i]instanceof  Magazine) {
				cnt++;
			}
		}
		int k=0;
		Magazine[] temp = new Magazine[cnt];{
		for(int i=0; i<size; i++) {
				if (books[i] instanceof  Magazine) {
					temp[k]=(Magazine) books[i];
					k+=1;
				}
			}
		}
		return temp;
	}
	
	public Book[] getBooks() {
		int cnt=0;
		for(int i=0; i<size; i++) {
			if (!(books[i]instanceof  Magazine)) {
				cnt++;
			}
		}
		int k=0;
		Book[] temp = new Book[cnt];{
		for(int i=0; i<size; i++) {
				if (!(books[i] instanceof  Magazine)) {
					temp[k]=books[i];
					k+=1;
				}
			}
		}
		return temp;
	}
	
	public void remove(String isbn) {
		for(int i=0; i<size; i++) {
			if ((books[i].getIsbn()).equals(isbn)){
				for (int j = i; j < books.length; j++) {
					if ((j+1)==books.length) {
						books[j]=null;
						break;
					}
					books[j]=books[j+1];
				}
				size-=1;
				break;
			}
		}
	}//end for remove method
	
	public Book searchByIsbn(String isbn) {
		Book temp = null;
		for(Book b : books) {
			if( b!= null) {
				if(b.getIsbn().equals(isbn)) {
					temp=b;
				}
			}
		}
		return temp;
	}
	
	public Book[] searchByTitle(String title) {
		Book[] temp = new Book[size];
		for(int i=0; i<size; i++) {
			if(books[i].getTitle().contains(title)) {
				temp[i]=books[i];
			}
		}
		return temp;
	}
	
	public int getTotalPrice() {
		int tmp=0;
		for(int i=0; i<size;i++) {
			tmp+=books[i].price;
		}
		return tmp;
	}
	
	public  double getPriceAvg() {
		double tmp=0;
		for(int i=0; i<size;i++) {
			tmp+=books[i].price;
		}
		return tmp/size;
	}
	
	
}
