package projectSSAFY;

public interface IBookManager {
	public void add(Book book);
	public Magazine[] getMagazines();
	public Book[] getBooks();
	public void remove(String isbn);
	public Book searchByIsbn(String isbn);
	public Book[] searchByTitle(String title);
	public int getTotalPrice();
	public double getPriceAvg();
}
