package test01;

public class Circle extends Shape{
	int radius;
	
	void draw() {
		System.out.println("나는 동그라미를 그립니다!!!");
	}
}
