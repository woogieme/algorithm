package test01;

public class Rectangle extends Shape{
	int width, height;
	
	void draw() {
		System.out.println("나는 사각형을 그립니다!!!");
	}
}
