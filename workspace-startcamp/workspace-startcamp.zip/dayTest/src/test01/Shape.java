package test01;

public class Shape {
	int x, y;
	void draw() {
		System.out.println("shape draw....? 뭘 그려....?");
	}
	static void f() {
		System.out.println("AAA");
	}
}
